#include <stdio.h>

int main(){
	puts("Test string!");
	return 0;
}
