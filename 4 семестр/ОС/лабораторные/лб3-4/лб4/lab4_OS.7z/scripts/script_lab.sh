#!/bin/bash
scriptreplay --timing=time_log scrpt $1
