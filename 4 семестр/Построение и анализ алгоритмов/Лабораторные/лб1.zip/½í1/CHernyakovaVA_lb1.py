print('Hello world!')
