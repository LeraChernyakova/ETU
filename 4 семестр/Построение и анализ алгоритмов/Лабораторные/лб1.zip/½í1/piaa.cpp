#include <iostream>
#include <queue>
#include <vector>

struct Square{
    int size;
    int x_coord;
    int y_coord;
    
    Square(int size, int x, int y):size(size), x_coord(x), y_coord(y){}
    friend std::ostream& operator<<(std::ostream& os, const Square& square){
        os << square.x_coord <<' '<< square.y_coord<< ' ' << square.size << std::endl;
        return os;
    }
};

class Desk{
private:
    std::vector<std::vector<int>> map;
    int side_len;
    int count_squares;
    std::vector<Square*> square_list;
public:
    
    Desk(int n):side_len(n){
        this->map = std::vector<std::vector<int>>();
        for(auto i = 0; i < side_len; i++){
            this->map.push_back(std::vector<int>(n));
        }
        this->square_list = std::vector<Square*>();
        this->count_squares = 0;

        if(n % 2 != 0 && n % 3 != 0){
            this->set_default();
        }
    }

    Desk(const Desk& obj):side_len(obj.side_len), count_squares(obj.count_squares){
        this->map = std::vector<std::vector<int>>();
        for(auto i = 0; i < side_len;i++){
            this->map.push_back(std::vector<int>(this->side_len));
        }
        for(auto i = 0; i < side_len; i++){
            for(auto j = 0; j < side_len; j++){
                this->map[i][j] = obj.map[i][j];
            }
        }
        this->square_list = std::vector<Square*>(obj.square_list);
    }

    Desk& operator=(const Desk& obj){
        if(this != &obj){
            this->map = std::vector<std::vector<int>>();
            for(auto i = 0; i < side_len;i++){
                this->map.push_back(std::vector<int>(this->side_len));
            }
            for(auto i = 0; i < side_len; i++){
                for(auto j = 0; j < side_len; j++){
                    this->map[i][j] = obj.map[i][j];
                }
            }
            side_len = obj.side_len;
            count_squares = obj.count_squares;
            square_list = std::vector<Square*>(obj.square_list);
        }
        return *this;
    }

    void set_default(){
        this->addSquare((side_len+1)/2, 0, 0, count_squares);
        this->addSquare((side_len-1)/2, 0, (side_len+1)/2, count_squares);
        this->addSquare((side_len-1)/2, (side_len+1)/2, 0, count_squares);
    }

    void addSquare(int size, int x, int y, int color){
        Square* square = new Square(size, x, y);
        for(auto i = x; i < x + size; i++){
            for(auto j = y; j < y + size; j++){
                this->map[i][j] = color+1;
            }
        }
        this->square_list.push_back(square);
        this->count_squares++;
    }

    bool is_full(){
		for (int i = 0; i < side_len; i++)
			for (int j = 0; j < side_len; j++)
				if (map[i][j] == 0)
					return false;
		return true;

	}

    bool can_add(int x, int y, int size){
        if(y+size > this->side_len || x+size > this->side_len)
            return false;
        for(auto i = x; i < x+size; i++){
            for(auto j = y; j < y+size; j++){
                if(this->map[i][j] != 0) return false;
            }
        }
        return true;
    }

    std::pair<int, int> empty_cell(){
        for(auto i = 0; i < this->side_len; i++){
            for(auto j = 0; j < this->side_len; j++){
                if(this->map[i][j] == 0) return std::pair<int, int>{i, j};
            }
        }
        return std::pair<int, int>{-1, -1};
    }

    int getSideLen() const{
        return side_len;
    }

    std::vector<Square*> getSquareList() const{
        return square_list;
    }

    int getSquareCount() const{
        return count_squares;
    }
};

Desk backtracking(Desk desk){
    std::queue<Desk> queue = std::queue<Desk>();
    queue.push(desk);
    while(!queue.front().is_full()){
        Desk s = queue.front();
        std::pair<int, int> empty_cell = s.empty_cell();    
        for(int i = desk.getSideLen() - 1; i > 0 ; i--){
            Desk cur = s;
            if(s.can_add(empty_cell.first, empty_cell.second, i)){
                cur.addSquare(i, empty_cell.first, empty_cell.second, cur.getSquareCount());
                queue.push(cur);
            }
        }
        queue.pop();
    }
    return queue.front();
}

int main(){
    int n;
    std::cin>>n;

    Desk desk = Desk(n);
    Desk answer = backtracking(desk);

    std::cout << answer.getSquareCount() << std::endl;
    for(auto elem:answer.getSquareList()){
        std::cout << *elem;
    }

    return 0;
}