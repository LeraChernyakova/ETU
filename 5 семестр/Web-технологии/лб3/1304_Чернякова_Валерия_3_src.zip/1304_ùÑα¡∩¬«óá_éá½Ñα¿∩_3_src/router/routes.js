const express = require("express");
const bodyParser = require("body-parser");
const allUsersStorage = require("../storages/allUsers.json");
const {getAllUsers, getUser, updateUserInfo, getUserFriends, getFriendsNews, getUserChats} = require("./routesFunction");

const router = express.Router();

router.use(bodyParser.urlencoded({ extended: true }));
router.use(express.json());

router.get('/',(req, res) => {
    res.render('startPage');
});

router.get('/admin',(req, res) => {
    res.render('usersPage', {users: getAllUsers()});
});

router.get('/admin/user/:id',(req, res) => {
   const currentUserId = parseInt(req.params.id);
   res.json(getUser(currentUserId));
});

router.post('/admin/user/update', (req, res) => {
    updateUserInfo(req);
    res.json({ success: true, message: 'Данные пользователя обновлены успешно.' });
});

router.get('/admin/friends/:id',(req, res) => {
    const currentUserId = parseInt(req.params.id);
    const currentUserData = allUsersStorage.find(user => user._id === currentUserId);
    res.render('usersFriends',{users: getUserFriends(currentUserId), currentUser: currentUserData});
});

router.get('/admin/news/:id',(req, res) => {
    const currentUserId = parseInt(req.params.id);
    const currentUserData = allUsersStorage.find(user => user._id === currentUserId);
    res.render('usersNews', {usersNews: getFriendsNews(currentUserId), currentUser: currentUserData});
});

router.get('/admin/chats/:id', (req, res) => {
    const currentUserId = parseInt(req.params.id);
    const currentUserData = allUsersStorage.find(user => user._id === currentUserId);
    res.render('usersChats', {usersChats: getUserChats(currentUserId), currentUser: currentUserData});
});

module.exports = router;