const fs = require("fs");
const path = require('path');
const allUsersStorage = require("../storages/allUsers.json");
const usersFriendsStorage = require("../storages/usersFriends.json");
const usersNewsStorage = require("../storages/usersNews.json");
const newsStorage = require("../storages/news.json");
const usersChatsStorage = require("../storages/usersChats.json");
const messagesStorage = require("../storages/messages.json");

exports.getAllUsers = function() {
    return allUsersStorage;
};

exports.getUser = function(currentUserId) {
    return allUsersStorage.find(user => user._id === currentUserId);
};

exports.updateUserInfo = function(req) {
    const { userID, FIO, birth, mail, role, status } = req.body;
    const userIndex = allUsersStorage.findIndex(user => user._id === Number(userID));
    allUsersStorage[userIndex].FIO = FIO;
    allUsersStorage[userIndex].birth = birth;
    allUsersStorage[userIndex].mail = mail;
    allUsersStorage[userIndex].role = role;
    allUsersStorage[userIndex].status = status;
    fs.writeFileSync(path.join(__dirname, '../storages/allUsers.json'),
        JSON.stringify(allUsersStorage, null, 2));
};

exports.getUserFriends = function(currentUserId) {
    const userFriendsId = usersFriendsStorage.find(user => user._id === currentUserId).friendsID;
    let userFriendsInfo = [];
    userFriendsId.forEach( userID => {
        const index = allUsersStorage.findIndex(user => user._id === userID);
        userFriendsInfo.push(allUsersStorage[index]);
    });
    return userFriendsInfo;
};

exports.getFriendsNews = function(currentUserId) {
    const userFriendsId = usersFriendsStorage.find(user => user._id === currentUserId).friendsID;
    let usersNews = [];
    userFriendsId.forEach( userID => {
        const userIndex = allUsersStorage.findIndex(user => user._id === userID);
        const userFIO = allUsersStorage[userIndex].FIO;
        const newsID = usersNewsStorage.find(user => user._id === userID).newsID;
        newsID.forEach( newsID => {
            const newsIndex = newsStorage.findIndex(news => news._id === newsID);
            const newsData = {
                FIO: userFIO,
                ...newsStorage[newsIndex]
            };
            usersNews.push(newsData);
        })
    })
    usersNews.sort(sortNews);
    return usersNews;
};

exports.getUserChats = function(currentUserId) {
    const userChatsId = usersChatsStorage.find(user => user._id === currentUserId)?.secondUsers || [];
    const msgData = messagesStorage;
    const chats = userChatsId.map(secondUserID => {
        const communication = msgData
            .filter(msg => (msg.userToID === secondUserID && msg.userFromID === currentUserId)
                || (msg.userToID === currentUserId && msg.userFromID === secondUserID))
            .map(msg => {
                const userTo = allUsersStorage.find(user => user._id === msg.userToID).FIO;
                const userFrom = allUsersStorage.find(user => user._id === msg.userFromID).FIO;
                return {
                    From: userFrom,
                    To: userTo,
                    ...msg
                };
            });
        return communication.length ? communication.sort(sortMessages) : [];
    });
    return chats.filter(chat => chat.length > 0);
};

function toDate(data) {
    const string = data.split('.');
    let date = string[2];
    date += '-';
    date += string[1];
    date += '-';
    date += string[0];
    return date;
}

function sortNews(first, second) {
    const dateComparison = toDate(second.date).localeCompare(toDate(first.date));
    if (dateComparison !== 0) {
        return dateComparison;
    }
    return second.time.localeCompare(first.time);
}

function sortMessages(first, second) {
    const dateComparison = toDate(first.date).localeCompare(toDate(second.date));
    if (dateComparison !== 0) {
        return dateComparison;
    }
    return first.time.localeCompare(second.time);
}