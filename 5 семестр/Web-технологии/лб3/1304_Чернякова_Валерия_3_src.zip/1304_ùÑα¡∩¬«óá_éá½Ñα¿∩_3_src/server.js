const express = require("express");
const https = require("https");
const fs = require("fs");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
const port = 3000;

const options = {
    key: fs.readFileSync(path.join(__dirname, "tools/domain.key")),
    cert: fs.readFileSync(path.join(__dirname, "tools/domain.crt")),
};

app.set("view engine", "pug");
app.set("views", path.join(__dirname, "views"));

app.use("/", require("./router/routes"));
app.use(bodyParser.urlencoded({ extended: true }));

app.use("/public", express.static(path.join(__dirname, "public")));

const server = https.createServer(options, app);

server.listen(port, () => {
    console.log(`Сервер запущен. Прослушивание порта ${port}!`);
});