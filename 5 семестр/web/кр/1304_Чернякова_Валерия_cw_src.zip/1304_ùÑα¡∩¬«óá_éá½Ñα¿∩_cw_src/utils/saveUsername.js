const getUsername = () => {
    localStorage["ninja.username"] = document.getElementById("player").value;
};