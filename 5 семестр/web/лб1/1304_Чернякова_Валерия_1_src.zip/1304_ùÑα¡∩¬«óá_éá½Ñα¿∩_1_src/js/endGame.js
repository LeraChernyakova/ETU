export function redirection(finalScore) {
    saveGameScore(finalScore);
    document.location.href = "/end_screen.html";
}

function saveGameScore(finalScore) {
    let username = localStorage.getItem('tetris.username');
    let allScores = localStorage.getItem('tetris.allScores');
    let scoreTable;
    if (!allScores) {
        scoreTable = {};
    }
    else {
        scoreTable = JSON.parse(localStorage.getItem('tetris.allScores'));
    }
    if(!scoreTable[username] || Number(scoreTable[username]) < Number(finalScore)){
        scoreTable[username] = finalScore;
        localStorage.setItem('tetris.score', finalScore);
    }
    else {
        localStorage.setItem('tetris.score', scoreTable[username]);
    }
    localStorage.setItem('tetris.allScores', JSON.stringify(scoreTable));
}