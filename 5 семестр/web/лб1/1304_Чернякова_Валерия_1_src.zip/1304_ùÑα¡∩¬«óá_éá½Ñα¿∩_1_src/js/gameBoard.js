import {columns, rows, scoreOfDeletedLines} from "./constants.js";
import {redirection} from "./endGame.js";
import {createTetramino} from "./tetramino.js";

export default class GameBoard {
    gameBoard = Array.from({length: rows}, () => Array(columns).fill(0));
    currentTetramino = createTetramino();
    nextTetramino = createTetramino();
    deletedLines = 0;
    score = 0;
    level = 1;
    endGame = false;
    subscriber = null;

    getGameBoardState() {
        if (!this.endGame){
            const gameBoardBuffer = structuredClone(this.gameBoard);
            const {y: yCoord, x: xCoord, cells} = this.currentTetramino;
            for (let y = 0; y < cells.length; y++) {
                for (let x = 0; x < cells[y].length; x++) {
                    if (cells[y][x]) {
                        gameBoardBuffer[yCoord + y][xCoord + x] = cells[y][x];
                    }
                }
            }
            return {
                gameBoard: gameBoardBuffer,
                endGame: this.endGame,
                score: this.score,
                nextTetramino: this.nextTetramino,
                currentTetramino: this.currentTetramino
            }
        }
        else {
            redirection(this.score);
        }
    }

    replaceTetraminoLeft() {
        this.currentTetramino.x--;
        if (this.hasCrash()) {
            this.currentTetramino.x++;
        }
    }

    replaceTetraminoRight() {
        this.currentTetramino.x++;
        if(this.hasCrash()) {
            this.currentTetramino.x--;
        }
    }

    rotateTetramino() {
        let cells = this.currentTetramino.cells;
        this.currentTetramino.cells = cells[0].map((value, index) =>
            cells.map(row => row[index]).reverse());
        if (this.hasCrash()) {
            this.currentTetramino.cells = cells[0].map((value, index) =>
                cells.map(row => row[row.length-1-index]));
        }
    }

    replaceTetraminoDown() {
        if (this.endGame) {
            return;
        }
        this.currentTetramino.y++;
        if(this.hasCrash()) {
            this.currentTetramino.y--;
            this.fixTetramino();
            const deletedLinesCount = this.deleteLines();
            this.updateScore(deletedLinesCount);
            this.updateTetramines();
        }
        if (this.hasCrash()) {
            this.endGame = true;
        }
    }


    hasCrash() {
        const {x: xCoord, y: yCoord, cells } = this.currentTetramino;
        for (let y = 0; y < cells.length; y++) {
            for (let x = 0; x < cells[y].length; x++) {
                if (
                    cells[y][x] &&
                    (
                        (
                            this.gameBoard[yCoord + y] === undefined ||
                            this.gameBoard[yCoord + y][xCoord + x] === undefined
                        ) || this.gameBoard[yCoord+y][xCoord+x]
                    )
                ) {
                    return true;
                }
            }
        }
        return false;
    }

    fixTetramino() {
        const {x: xCoord, y: yCoord, cells } = this.currentTetramino;
        for (let y = 0; y < cells.length; y++) {
            for (let x = 0; x < cells[y].length; x++) {
                if (cells[y][x]) {
                    this.gameBoard[yCoord + y][xCoord + x] = cells[y][x];
                }
            }
        }
    }

    updateTetramines() {
        this.currentTetramino = this.nextTetramino;
        this.nextTetramino = createTetramino();
    }

    deleteLines() {
        let totallyFillLines = [];
        for (let y = rows - 1; y >= 0; y--) {
            let fillCellsCount = 0;
            for (let x = 0; x < columns; x++) {
                if (this.gameBoard[y][x]) {
                    fillCellsCount += 1;
                }
            }
            if (fillCellsCount === 0){
                break;
            }
            else if (fillCellsCount === columns) {
                totallyFillLines.unshift(y);
            }
        }
        for (let index of totallyFillLines) {
            this.gameBoard.splice(index,1);
            this.gameBoard.unshift(new Array(columns).fill(0));
        }
        return totallyFillLines.length
    }

    updateScore(deletedLinesCount) {
        if (deletedLinesCount) {
            this.deletedLines += deletedLinesCount;
            this.score += scoreOfDeletedLines * deletedLinesCount;
            this.level = Math.floor(this.score / 300) + 1;
            if (this.level > 1) {
                if (this.score >= (this.level - 1) * 300) {
                    this.updateInterval();
                }
            }
        }
    }

    subscribe(obj){
        this.subscriber = obj;
    }
    updateInterval() {
        this.subscriber.updateInterval();
    }
}