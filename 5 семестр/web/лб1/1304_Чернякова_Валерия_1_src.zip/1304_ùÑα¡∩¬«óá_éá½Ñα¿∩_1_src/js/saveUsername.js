function getUsername() {
    localStorage["tetris.username"] = document.getElementById("player").value;
}