start(1, 1).
stop(4, 4).
go:- start(X, Y), move(X, Y).
move(X, Y) :- stop(X, Y).
move(X, Y) :- X < 5, X1 is X + 1, move(X1, Y).
move(X, Y) :- Y < 5, Y1 is Y + 1, move(X, Y1).


