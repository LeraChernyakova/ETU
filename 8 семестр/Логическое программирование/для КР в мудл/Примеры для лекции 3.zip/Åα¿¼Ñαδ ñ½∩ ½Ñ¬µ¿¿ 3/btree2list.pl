btree2list(Tree,List):- btree2list(Tree,[],List).
btree2list(nil,List,List).
btree2list(btree(Root,Left,Right),List,[Root | RList]):- 
 btree2list(Left,List,List1), btree2list(Right,List1,RList).
