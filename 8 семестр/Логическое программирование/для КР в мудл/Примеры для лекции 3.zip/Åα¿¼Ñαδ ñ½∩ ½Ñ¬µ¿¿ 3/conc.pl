conc([],L,L).
conc([Head|Tail],L,[Head|NewTail]) :- conc(Tail,L,NewTail).