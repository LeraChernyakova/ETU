del(X,[X|L],L).
del(X,[Y|L],[Y|L1]):-del(X,L,L1).