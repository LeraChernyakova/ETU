del_all(X,[],[]).
del_all(X,[H|L],L1):-X=H, del_all(X,L,L1).
del_all(X,[H|L],[H|L1]):-X\=H, del_all(X,L,L1).