in(Item, btree(Item, _, _)).
in(Item, btree(_, Left, _)) :- in(Item, Left).
in(Item, btree(_,_, Right)) :- in(Item, Right).
