conc([],L,L).
conc([Head|Tail],L,[Head|NewTail]) :- conc(Tail,L,NewTail).
memb1(X,L):-conc(_,[X|_],L).