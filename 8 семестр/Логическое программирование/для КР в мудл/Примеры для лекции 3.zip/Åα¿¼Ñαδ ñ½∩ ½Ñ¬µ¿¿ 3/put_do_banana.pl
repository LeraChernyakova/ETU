start(1,1).
stop(4,4).
go(Path):- start(X,Y),move(X,Y,[],Path).
move(X,Y,P,[m(X,Y)|P]):- stop(X, Y).
move(X,Y,From,[m(X,Y) | To]):- X<5, X1 is X+1, move(X1,Y,From,To).
move(X,Y,From,[m(X,Y) | To]):- Y<5, Y1 is Y+1, move(X,Y1,From,To).