del(X,[X|L],L).
del(X,[Y|L],[Y|L1]):-del(X,L,L1).
rearrangement([],[]).
rearrangement(L,[X | P]) :- del(X,L,L1),rearrangement(L1, P).
ordered([]).
ordered([_]).
ordered([X, Y | T]) :- X < Y,ordered([Y|T]).
sorts(X,Y):- rearrangement(X,Y),ordered(Y).