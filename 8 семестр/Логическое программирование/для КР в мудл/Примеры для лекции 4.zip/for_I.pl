for(N,N).
for(I,N) :- I<N,write(I),nl,I1 is I+1,for(I1,N).