memb(Elem,[Elem|_]).
memb(Elem,[_|Tail]) :- memb(Elem,Tail).