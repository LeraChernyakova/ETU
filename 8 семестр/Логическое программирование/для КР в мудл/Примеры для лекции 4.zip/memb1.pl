memb1(Elem,[Elem|_]) :- !.
memb1(Elem,[_|Tail]) :- memb1(Elem,Tail).