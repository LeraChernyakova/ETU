memb1(Elem,[Elem|_]).
memb1(Elem,[_|Tail]) :- memb1(Elem,Tail).
minus([ ], _, [ ]).
minus([X | L1], L2, L) :- memb1(X, L2), !, minus(L1, L2, L).
minus([X | L1], L2, [X | L]) :- minus(L1, L2, L).
