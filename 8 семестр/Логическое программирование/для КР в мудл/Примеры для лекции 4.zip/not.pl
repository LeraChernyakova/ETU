not(X) :- X, !, fail.
not(_).
