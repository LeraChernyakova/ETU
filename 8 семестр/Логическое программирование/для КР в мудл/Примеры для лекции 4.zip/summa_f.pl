p(A,X) :- read_integer(I),I=\=0,A1 is A+I,p(A1,X),!.
p(A,X) :- X is A.
summa(A,X):-see('chisla.txt'),p(A,X),write('�����='),write(X),nl,seen.