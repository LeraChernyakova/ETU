init(Var, Val) :- assertz(variables(Var,Val)).
set(Var, Val) :- retract(variables(Var, _)), assertz(variables(Var,Val)).
get(Var, Val) :- variables(Var, Val).
