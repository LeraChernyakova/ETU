:- dynamic(variables/2). 
get(X,Y) :- variables(X,Y). 
set(X,Y) :- assertz(variables(Y,X)), assertz(variables(X,Y)). 
translate(X) :- get(X, Y), write(Y),!; 
      write('Not such word, give translation: '), 
      read_atom(Z), set(X, Z).
