age(peter, 7).
age(ann, 5).
age(tom, 12).
age(alex, 5).
