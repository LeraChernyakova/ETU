fathers([ai, fs, vp, ga]).
sons([l, k, a, d]).

check(L):-member(trio(ai, _, l), L),
member(trio(FatherK, k, _), L), member(trio(FatherK, _, a), L),
member(trio(FatherA, a, _), L), member(trio(FatherA, _, d), L),
member(trio(vp, SonVP, _), L), member(trio(fs, _, SonVP), L),
member(trio(ai, SonAI, _), L), member(trio(vp, _, SonAI), L).

generate([trio(F1, S1, C1), trio(F2, S2, C2), trio(F3, S3, C3), trio(F4, S4, C4)]):-
fathers([F1, F2, F3, F4]),
sons(S), permutation(S, [S1, S2, S3, S4]), 
sons(C), permutation(C, [C1, C2, C3, C4]).

go(L):-generate(L), check(L).
