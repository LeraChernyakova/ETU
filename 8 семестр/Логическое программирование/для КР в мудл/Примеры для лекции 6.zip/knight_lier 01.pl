% Утверждения островитян
told(a, [lier, lier, lier]).
told(b, [knight, lier, lier]).
told(b, [lier, knight, lier]).
told(b, [lier, lier,  knight]).

% Либо А-рыцарь и его утв. верно, либо он лжец и лжёт
check(a, [A, B, C]) :- 
	A= knight, told(a, [A, B, C]); 
	A= lier, (B= knight, C= lier; B= lier, C= knight; B= knight, C= knight).

% Либо В-рыцарь и его утв. верно, либо он лжец и лжёт
check(b, [A, B, C]) :- 
	B= knight, told(b, [A, B, C]); 
	B= lier, (A= lier, C= lier; A= knight, C= knight).

% Необходимо проверить утверждения А и В
go([A, B, C]) :- check(a, [A, B, C]), check(b, [A, B, C]).

