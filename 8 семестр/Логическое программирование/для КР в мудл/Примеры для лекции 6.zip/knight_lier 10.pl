% Перечисляем утверждения островитян А и В
firstOpinion(lier, lier, lier).
secondOpinion(knight, lier, lier).
secondOpinion(lier, knight, lier).
secondOpinion(lier, lier, knight).

% Перебираем варианты лжец/рыцарь для каждого из островитян
heIs(lier).
heIs(knight).

% Ищем решение
go(A, B, C) :- 
	heIs(A), heIs(B), heIs(C), testOpinions(A, B, C).

% Проверяем утверждения первого и второго
% Если он лжец, то его утверждение ложно
% Если он рыцарь, то его утверждение истинно
testOpinions(A, B, C) :-
	(A == lier, \+(firstOpinion(A, B, C)) ; 
	A == knight, firstOpinion(A, B, C)),
	(B == lier, \+(secondOpinion(A, B, C)) ; 
	B == knight, secondOpinion(A, B, C)).
