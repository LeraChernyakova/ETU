plus(X, Y, Z) :- nonvar(X), nonvar(Y), Z is X + Y.
plus(X, Y, Z) :- nonvar(X), nonvar(Z), Y is Z - X.
plus(X, Y, Z) :- nonvar(Z), nonvar(Y), X is Z - Y.
