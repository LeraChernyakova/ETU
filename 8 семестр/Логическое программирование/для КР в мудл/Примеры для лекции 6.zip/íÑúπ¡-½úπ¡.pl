alex([_,a,_,_]).
alex([_,_,a,_]).
boris([b,_,_,_]).
boris([_,b,_,_]).
boris([_,_,b,_]).
ivan([i,_,_,_]).
grig([_,_,_,g]).
go(L):-permutation([a,b,i,g], L),
(alex(L), boris(L), ivan(L), \+(grig(L));  % вместо not – предикат “\+”
alex(L), boris(L), \+(ivan(L)), grig(L);
alex(L), \+(boris(L)), ivan(L), grig(L);
\+(alex(L)), boris(L), ivan(L), grig(L)).
