triple(F, F3) :- F =.. [Name | P], mult(P, P3), F3 =.. [Name | P3].
mult([], []).
mult([X|T], [Y|T3]) :- mult(T, T3), Y is X * 3.
